import { useEffect, useState } from 'react';

import { Grid, Box } from '@mui/material';
import { Link, useSearchParams } from 'react-router-dom';

// import { getAllPosts } from '../../../service/api';
import { API } from '../../../service/api';

//components
import Post from './Post';

const Posts = () => {
    const [posts, getPosts] = useState([]);
    const [filterdPosts, setFilterdPosts] = useState([]);
    
    const [searchParams] = useSearchParams();
    const category = searchParams.get('category');
    const onChange = (e)=>{
        let text = e.target.value;
        if(text===''){
            setFilterdPosts(posts);
        }else{
            const post = filterdPosts.filter(({title}) => title.toLowerCase().includes(text));
            setFilterdPosts(post);
        }
    }
    useEffect(() => {
        const fetchData = async () => { 
            let response = await API.getAllPosts({ category : category || '' });
            if (response.isSuccess) {
                getPosts(response.data);
                setFilterdPosts(response.data);
            }
        }
        fetchData();
    }, [category]);

    return (
        <>
            <input type={"text"} placeholder={"Search Blog"} style={{position:'relative',width:'100%',padding:'8px',marginTop:'20px'}} onChange={onChange} />
            {
                filterdPosts?.length ? filterdPosts.map(post => (
                    <Grid item lg={3} sm={4} xs={12}>
                        <Link style={{textDecoration: 'none', color: 'inherit'}} to={`details/${post._id}`}>
                            <Post post={post} />
                        </Link>
                    </Grid>
                )) : <Box style={{color: '878787', margin: '30px 80px', fontSize: 18}}>
                        No data is available for selected category
                    </Box>
            }
        </>
    )
}

export default Posts;