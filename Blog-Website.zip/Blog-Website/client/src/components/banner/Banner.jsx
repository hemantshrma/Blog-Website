import { useState, useEffect } from 'react';
import { styled, Box, Typography } from '@mui/material';

const images = [
  'https://e1.pxfuel.com/desktop-wallpaper/201/793/desktop-wallpaper-bambi-w-on-aesthetic%E2%9C%A8-autumn-study-aesthetic-thumbnail.jpg',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTmKJAn5E3D1kcvq21NlbADsYw3g9B8kCSkQ&usqp=CAU',
  'https://i.pinimg.com/736x/37/6c/33/376c3384d6179e17d155128b42f2b63c.jpg',
];

const Image = styled(Box)`
  width: 100%;
  height: 50vh; /* Adjust the height value as needed */
  display: flex;
  align-items: center;
  justify-content: center;
  background-position: center/55% repeat;
  background-image: url(${props => props.imageUrl});
`;


const Heading = styled(Typography)`
  font-size: 50px;
  background: #FFFFFF;
  line-height: 1;
`;

const SubHeading = styled(Typography)`
  font-size: 20px;
  background: #FFFFFF;
`;

const Banner = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentImageIndex(prevIndex =>
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000); // Change the duration between image changes (in milliseconds) here

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  return (
    <Image imageUrl={images[currentImageIndex]}>
      {/* <Heading>MEDIUM BLOG...</Heading> */}
    </Image>
  );
};

export default Banner;
