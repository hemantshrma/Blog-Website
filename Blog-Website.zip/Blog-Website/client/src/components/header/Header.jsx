// import { AppBar, Toolbar, styled, Button } from '@mui/material';
// import { Link } from 'react-router-dom';
// import { useNavigate } from 'react-router-dom';

// const Component = styled(AppBar)`
//   background: #FFFFFF;
//   color: black;
// `;

// const Container = styled(Toolbar)`
//   justify-content: center;
//   & > a {
//     padding: 20px;
//     color: #000;
//     text-decoration: none;
//   }
// `;

// const Header = () => {
//   const navigate = useNavigate();

//   const logout = async () => navigate('/account');

//   return (
//     <Component>
//       <Container>
//         <Link to='/' style={{ display: 'flex', alignItems: 'center' }}>
//           <img
//             src='https://miro.medium.com/v2/resize:fit:8978/1*s986xIGqhfsN8U--09_AdA.png'
//             alt='Logo'
//             style={{ height: '50px', marginRight: '590px' }}
//           />
//           HOME
//         </Link>
//         <Link to='/about'>ABOUT</Link>
//         <Link to='/contact'>CONTACT</Link>
//         <Link to='/account'>LOGOUT</Link>
//       </Container>
//     </Component>
//   );
// };

// export default Header;


import { AppBar, Toolbar, styled, Button, InputBase } from '@mui/material';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Component = styled(AppBar)`
  background: #FFFFFF;
  color: black;
`;

const Container = styled(Toolbar)`
  justify-content: center;
  & > a {
    padding: 20px;
    color: #000;
    text-decoration: none;
  }
`;

const SearchContainer = styled('div')`
  display: flex;
  align-items: center;
  border: 1px solid #000;
  padding: 5px;
  margin-right: 20px;
`;

const SearchInput = styled(InputBase)`
  flex-grow: 1;
  margin-left: 5px;
`;

const Header = () => {
  const navigate = useNavigate();

  const logout = async () => navigate('/account');

  return (
    <Component>
      <Container>
        <Link to='/' style={{ display: 'flex', alignItems: 'center' }}>
          <img
            src='https://miro.medium.com/v2/resize:fit:8978/1*s986xIGqhfsN8U--09_AdA.png'
            alt='Logo'
            style={{ height: '50px', marginRight: '590px' }}
          />
          HOME
        </Link>
        <Link to='/about'>ABOUT</Link>
        <Link to='/contact'>CONTACT</Link>
        <Link to='/account'>LOGOUT</Link>
      </Container>
    </Component>
  );
};

export default Header;
